from flask import Flask, request, redirect, url_for, render_template, flash, session, g
from random import randint
import requests
from flask_mail import Mail, Message
from flask_bcrypt import Bcrypt
from pymongo import MongoClient
from dotenv import load_dotenv
import sqlite3
import os

load_dotenv()

application = Flask(__name__, template_folder='template')
application.secret_key = os.getenv('SECRET_KEY', 'movie-project')

# Flask mail configuration
application.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER')
application.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', 587))
application.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
application.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
application.config['MAIL_USE_TLS'] = True
application.config['MAIL_USE_SSL'] = False

mail = Mail(application)
bcrypt = Bcrypt(application)

# Database connections
def get_mongo_db():
    try:
        mongo_uri = os.getenv('MONGODB_URI')
        client = MongoClient(mongo_uri)
        db = client["SWEHUL"]
        return db
    except Exception as e:
        print(f"Failed to connect to MongoDB: {e}")
        return None

def get_sqlite_db():
    try:
        conn = sqlite3.connect('database.db')
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Failed to connect to SQLite: {e}")
        return None

@application.before_request
def before_request():
    g.db = get_mongo_db()
    if g.db is None:
        g.db = get_sqlite_db()

@application.teardown_request
def teardown_request(exception):
    db = g.pop('db', None)
    if db is not None:
        if isinstance(db, sqlite3.Connection):
            db.close()


# OMDb API Key
OMDB_API_KEY = os.getenv('OMDB_API_KEY')

# Route to fetch latest movie releases and display basic details
@application.route("/latest_movies")
def latest_movies():
    try:
        url = f"http://www.omdbapi.com/?s=movie&type=movie&r=json&apikey={OMDB_API_KEY}"
        response = requests.get(url)
        data = response.json()
        if 'Search' in data:
            movies = data['Search']
            return render_template('latest_movies.html', movies=movies)
        else:
            return jsonify({"error": "No movies found"})
    except Exception as e:
        return jsonify({"error": str(e)})


# Route for user to rate a movie
@application.route("/rate_movie", methods=['POST'])
def rate_movie():
    # Get movie title and rating from the form
    movie_title = request.form.get('movie_title')
    rating = request.form.get('rating')

    # Store the rating in the database or perform any desired action

    flash("Thank you for rating the movie!")
    return redirect(url_for('latest_movies'))

# Route for user to comment on a movie
@application.route("/comment_movie", methods=['POST'])
def comment_movie():
    # Get movie title and comment from the form
    movie_title = request.form.get('movie_title')
    comment = request.form.get('comment')

    # Store the comment in the database or perform any desired action

    flash("Thank you for commenting on the movie!")
    return redirect(url_for('latest_movies'))

# Route for user to like a comment on a movie
@application.route("/like_comment", methods=['POST'])
def like_comment():
    # Get comment ID from the form
    comment_id = request.form.get('comment_id')

    # Increment the like count for the specified comment in the database or perform any desired action

    flash("Thank you for liking the comment!")
    return redirect(url_for('latest_movies'))

# Route for user to reply to a comment on a movie
@application.route("/reply_comment", methods=['POST'])
def reply_comment():
    # Get parent comment ID and reply from the form
    parent_comment_id = request.form.get('parent_comment_id')
    reply = request.form.get('reply')

    # Store the reply in the database or perform any desired action

    flash("Thank you for replying to the comment!")
    return redirect(url_for('latest_movies'))

@application.route("/home/", methods=['POST'])
def home():
    db = g.db
    email = request.form.get('usrmail')
    password = request.form.get('usrpswd')
    
    if isinstance(db, sqlite3.Connection):
        userdata = db.execute("SELECT * FROM userdata WHERE Email = ?", (email,)).fetchone()
    else:
        userdata = db["userdata"].find_one({"Email": email})
    
    if userdata and bcrypt.check_password_hash(userdata["Password"], password):
        session['gname'] = userdata["Name"]
        return redirect(url_for('index'))
    
    flash("Incorrect email or password.", 'message')
    return redirect(url_for("login"))

@application.route('/resend')
def resend_otp():
    phoneotp = randint(100000, 999999)
    emailotp = randint(100000, 999999)
    phone = request.args.get('usrphone')
    email = request.args.get('usrmail')
    
    if not email or not phone:
        flash("Email or phone number is missing.", 'message')
        return redirect(url_for("signup"))

    msg = Message('OTP VERIFY', sender=application.config['MAIL_USERNAME'], recipients=[email])
    msg.body = f"The OTP is {emailotp}"
    try:
        mail.send(msg)
    except Exception as e:
        flash(f"Failed to send email: {e}", 'message')
        return redirect(url_for("signup"))
    
    # Sending SMS using Fast2SMS
    my_data = {
        'sender_id': 'SMSINI',
        'message': f'Otp is {phoneotp}',
        'language': 'english',
        'route': 'p',
        'numbers': phone
    }
    headers = {
        'authorization': os.getenv('FAST2SMS_AUTH_KEY'),
        'Content-Type': "application/x-www-form-urlencoded",
        'Cache-Control': "no-cache"
    }
    try:
        response = requests.post("https://www.fast2sms.com/dev/bulk", data=my_data, headers=headers)
        response.raise_for_status()
        returned_msg = response.json()
        if returned_msg.get('return') != True:
            flash("Failed to send SMS OTP.", 'message')
            return redirect(url_for("signup"))
    except requests.RequestException as e:
        flash(f"Failed to send SMS: {e}", 'message')
        return redirect(url_for("signup"))

@application.route("/signup/", methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form.get('usrname')
        email = request.form.get('usrmail')
        phone = request.form.get('usrphone')
        password = request.form.get('usrpswd1')
        confirm_password = request.form.get('usrpswd2')
        
        if password != confirm_password:
            flash("Passwords don't match. Try signing up again.")
            return redirect(url_for('login'))

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    
    # Resend OTP
        session['name'] = name
        session['email'] = email
        session['phone'] = phone
        session['hashed_password'] = hashed_password
        return redirect(url_for('resend_otp'))
    else:
        return render_template('loin.html')

@application.route("/forgotpass/")
def forgotpass():
    return render_template("forgotpass.html")

@application.route("/changepass/", methods=['POST'])
def changepass():
    emailotp1 = randint(100000, 999999)
    femail = request.form.get('femail')
    
    db = g.db
    if isinstance(db, sqlite3.Connection):
        userdata = db.execute("SELECT * FROM userdata WHERE Email = ?", (femail,)).fetchone()
    else:
        userdata = db["userdata"].find_one({"Email": femail})
    
    if not userdata:
        flash("Email not found! Try signing up.")
        return redirect(url_for('login'))

    msg = Message('OTP VERIFY', sender=application.config['MAIL_USERNAME'], recipients=[femail])
    msg.body = f"The OTP is {emailotp1} to change the password."
    
    try:
        mail.send(msg)
        session['femail'] = femail
        session['emailotp1'] = emailotp1
        return render_template('changepass.html', email1=femail)
    except Exception as e:
        flash(f"Failed to send email: {e}", 'message')
        return redirect(url_for('login'))

@application.route("/changepassword/", methods=['POST'])
def changepassword():
    passw = request.form.get('usrpswd1')
    cpassw = request.form.get('usrpswd2')
    fotp = request.form.get('evotp')
    emailotp1 = session.get('emailotp1')
    femail = session.get('femail')
    
    if not emailotp1 or not femail:
        flash("Session expired. Please try again.", 'message')
        return redirect(url_for('login'))
    
    if int(fotp) != emailotp1:
        flash("Incorrect OTP. Please try again.", 'message')
        return render_template('changepass.html', email1=femail)

    if passw != cpassw:
        flash("Passwords don't match. Try again.", 'message')
        return render_template('changepass.html', email1=femail)
    
    hashed_password = bcrypt.generate_password_hash(passw).decode('utf-8')
    db = g.db
    
    try:
        if isinstance(db, sqlite3.Connection):
            db.execute("UPDATE userdata SET Password = ? WHERE Email = ?", (hashed_password, femail))
            db.commit()
        else:
            db["userdata"].update_one({"Email": femail}, {"$set": {"Password": hashed_password}})
        flash("Password changed successfully! Login again.")
        return redirect(url_for('login'))
    except Exception as e:
        flash(f"Failed to change password: {e}", 'message')
        return render_template('changepass.html', email1=femail)

@application.route("/verify/", methods=["POST"])
def verify():
    email = session.get('email')
    name = session.get('name')
    phone = session.get('phone')
    hashed_password = session.get('hashed_password')
    emailotp = session.get('emailotp')
    phoneotp = session.get('phoneotp')
    
    if not email or not name or not phone or not hashed_password or not emailotp or not phoneotp:
        flash("Session expired. Please try again.", 'message')
        return redirect(url_for('signup'))
    
    evotp = request.form.get('evotp')
    pvotp = request.form.get('pvotp')
    
    if int(evotp) != emailotp or int(pvotp) != phoneotp:
        flash("Incorrect OTP. Please try again.", 'message')
        return render_template('otp.html')
    
    db = g.db
    
    if isinstance(db, sqlite3.Connection):
        if db.execute("SELECT * FROM userdata WHERE Email = ?", (email,)).fetchone():
            flash("User already exists. Try logging in.")
            return redirect(url_for('login'))
        db.execute("INSERT INTO userdata (Name, Email, Phone, Password) VALUES (?, ?, ?, ?)", (name, email, phone, hashed_password))
        db.commit()
    else:
        if db["userdata"].find_one({"Email": email}):
            flash("User already exists. Try logging in.")
            return redirect(url_for('login'))
        db["userdata"].insert_one({"Name": name, "Email": email, "Phone": phone, "Password": hashed_password})
    
    session['gname'] = name
    return redirect(url_for('index'))

@application.route("/index/")
def index():
    gname = session.get('gname')
    if not gname:
        return redirect(url_for('login'))

    db = g.db
    movies = db["movies"].find()
    recommended_movies = db["recommended_movies"].find()
    
    return render_template('index.html', movies=movies, rmovies=recommended_movies, gname=gname)

# Route to render RateMovies.html
@application.route("/rate_movies")
def rate_movies():
    return render_template("RateMovies.html")

@application.route("/bookticket/", methods=['POST'])
def bookticket():
    title = request.form.get('text1')
    desc = request.form.get('text2')
    image = request.form.get('text3')
    usr = request.form.get('text4')
    
    db = g.db
    userdata = db["userdata"]
    user = userdata.find_one({"Name": usr})
    
    if not user:
        flash("User not found. Please log in.", 'message')
        return redirect(url_for('login'))
    
    return render_template('book.html', title=title, desc=desc, image=image, nam=user["Name"], mail1=user["Email"])

@application.route("/confirmed/", methods=['POST'])
def confirm():
    name = request.form.get('s6')
    email = request.form.get('s4')
    moviename = request.form.get('s5')
    theatre = request.form.get('s10')
    date = request.form.get('d1')
    timing = request.form.get('s11')
    number = request.form.get('s7')
    seats = request.form.get('s3')

    booking_data = {
        "Name": name,
        "Email": email,
        "Moviename": moviename,
        "Theatre": theatre,
        "Date": date,
        "Timing": timing,
        "Number": number,
        "Seats": seats
    }

    db = g.db
    bookings = db["booking"]
    
    try:
        bookings.insert_one(booking_data)
        msg = Message('Ticket Details', sender=application.config['MAIL_USERNAME'], recipients=[email])
        msg.body = f"""Hi {name}, 
        Movie: {moviename} 
        Theatre: {theatre}
        Date: {date}
        Timing: {timing}
        Number of Seats: {number}
        Seats: {seats}
        
        Thank you for booking! Enjoy the show!"""
        mail.send(msg)
        flash("Tickets booked successfully.")
        return redirect(url_for('index'))
    except Exception as e:
        flash(f"Failed to book tickets: {e}", 'message')
        return redirect(url_for('index'))

@application.route("/")
def login():
    return render_template('login.html')

if __name__ == "__main__":
    application.run(host="0.0.0.0", debug=True)
